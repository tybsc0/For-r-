#Q.1
s1<-c(37,49,7,38)
s2<-c(16,37,21,42,27,40,39,51)
sp<-s1+s2
sn<-(s1+s2)/2
sd<-s1/s2
sm<-s1*s2
sp
sn
sd
sm

#Q.2
a<-seq(1,37,by=3)
b<-seq(1,13)
length(a)
length(b)
c=a*b
d=a/b
e=a+b
f=a-b
c
d
e
f

#Q.3
y<-c(40,67,75,48,44,53,66,57,65,52,83,83,80,79,85,88,89,87)

mean(y)
median(y)

mode<-function(x)
{
  t1<-table(x)
  m1<-t1[t1==max(t1)]
  m2<-as.numeric(names(m1))
  return(m2)
}

mode(y)

log10(y)
log(y)
length(y)
sort(y, decreasing = FALSE)
summary(y)
range(y)
sd<-sqrt(var(y))
sd

#Q.4
A<-matrix(c(1,2,3,4), nrow=2, ncol=2, byrow=TRUE)
B<-matrix(c(2,8,6,12), nrow=2, ncol=2, byrow=TRUE)
A
B

A+B
B-A
A%*%B
det(A)
det(B)
solve(A)
solve(B)
t(A)
A%*%t(B)
t(A%*%B)
t(A)%*%t(B)

#Q.5
C<-matrix(c(1,3,5,8,5,5,2,3,1), nrow=3, ncol=3, byrow=TRUE)
D<-matrix(c(2,3,2,0,6,5,1,2,3), nrow=3, ncol=3, byrow=TRUE)
C
D
C+D
D-C
C%*%D
det(C)
det(D)
solve(C)
solve(D)
t(C)
C%*%t(D)
solve(t(C%*%D))
t(C)%*%t(D)

#Q.6
n<-seq(1,10)
x<-c(28,27,26,32,30,29,35,30,32,40)
y<-c(24,24,20,28,25,26,32,26,30,35)
d<-data.frame(n,x,y)
d
head(d)
tail(d)
nrow(d)
ncol(d)
d[1:3,]
d[8:10,]
d[1:3,1:2]
d[3,1]
Z<-(x+y)/2
transform(d,z=Z)

#Q.7
z1<-c(5,3,2,6,2,3,7,4,5,7)
c<-data.frame(n,z1)
d1<-merge(d,c, unique="n")
d1
library(dplyr)
rename(d1,z2=z1)
d1[-4]
d1[c(1,4)]

#Q.8
h<-c(140,137,150,147,139,140,150,132,138,140)
w<-c(55,57,59,62,61,60,60,58,59,57)
d<-data.frame(h,w);d
h1<-h[h>145];h1
w1<-w[w>55];w1
d2<-subset(d, h>140 & w>60);d2
