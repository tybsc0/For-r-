#Practical No.5.4.2
install.packages("ggplot2")
library(ggplot2)
data()
View(stackloss)
names(stackloss)
str(stackloss)
summary(stackloss)# extra 
ggplot(stackloss, aes(x=Air.Flow)) + geom_histogram()

# change bin width
ggplot(stackloss, aes(x=Air.Flow)) + geom_histogram(binwidth=5)

# add label title and colour to plot
ggplot(stackloss, aes(x=Air.Flow)) + geom_histogram(binwidth=5, color="black", fill= "green") + 
  ggtitle("Histogram of Air Flow") + xlab("Air flow") + ylab("Frequency") +
  theme(plot.title = element_text(hjust=0.5))

# box plot

ggplot(stackloss , aes(x = "", y = Air.Flow)) + geom_boxplot() + ggtitle("Boxplot of Air Flow")+ theme(plot.title = element_text(hjust=0.5)) 


# Scatter plot
ggplot(stackloss, aes(x=Air.Flow, y=Water.Temp)) + geom_point()

# add label title and colour to plot
ggplot(stackloss, aes(x=Air.Flow, y=Water.Temp))+ geom_point(colour = "blue") + ggtitle("Scatterplot") +  xlab("Air flow") + ylab("Water Temp") + theme(plot.title = element_text(hjust=0.5))
cor(stackloss$Air.Flow,stackloss$Water.Temp)
#Question 2
rm(a)
choose.files()
a<-read.csv("E:\\Class\\T.Y.B.Sc\\Notes\\Paper 4\\Data for practical\\University Practical data  for students\\loan_data.csv")
View(a)
str(a) # structure of data
names(a)
str(a)
head(a)
library(ggplot2)
# add label title and colour to plot
ggplot(a, aes(Purpose)) + geom_bar(fill = 'blue', color = 'yellow') + ggtitle("Purpose of Loan")+ xlab("Loan Purpose") + ylab("Count of Customers")+ theme(plot.title = element_text(hjust=0.5))
table(a$Purpose)
#write.csv(a, "a.csv")
#read.csv("C:\\Users\\Rahul Tiwari\\Desktop\\R software notes\\a.csv")
#View(a)
#write.csv ("a1a","C:\\Users\\Rahul Tiwari\\Desktop\\R software notes\\T.Y.B.Sc\\R\\University Practical\\a1.csv",header=T)

# multiple barplot
library("DataEditR")

ggplot(a, aes(Purpose)) + geom_bar(aes(fill = Creditability), color = 'lightblue', position="dodge")
names(a)
b<-data_edit(a)
View(b)
b$x
# Histogram
View(a)
ggplot(a, aes(x=Credit.Amount)) + geom_histogram()

ggplot(a, aes(x=Credit.Amount)) + geom_histogram(binwidth=1000, fill = "lightblue", color="red") + 
  ggtitle("Histogram of Credit Amount in Bank Account") + xlab("Credit Amount") + ylab("Count of Customers") +
  theme(plot.title = element_text(hjust=0.5))

# Boxplot
# univariate Boxplot
ggplot(a , aes(x = "",y = Credit.Amount)) + geom_boxplot()

ggplot(a , aes(x = Creditability, y = Credit.Amount)) + geom_boxplot(aes(fill = Creditability))

ggplot(a , aes(x = Creditability, y = Credit.Amount)) + geom_boxplot(aes(fill = Creditability)) +
  ggtitle("Boxplot of Credit amount in account based on customers Credibility") +
  xlab("Creditability") + ylab("Amount")

# frequency Polygon
ggplot(a, aes(Credit.Amount)) +geom_freqpoly(binwidth = 500)

ggplot(a, aes(Credit.Amount, color = Creditability)) +  geom_freqpoly(aes(fill= Creditability),binwidth = 500) + ggtitle("Frequency Polygon of Credit amount in account based on customers Credibility") +
  xlab("Credit.Amount") + ylab("Count")

# Scatterplot
ggplot(a, aes(x=Credit.Amount, y=Age.years)) + geom_point()

ggplot(a, aes(x=Credit.Amount, y=Age.years, shape=Creditability, color=Creditability)) + geom_point() +
  ggtitle("Scatterplot of Credit Amount v/s Age in Years") +
  xlab("Credit Amount") + ylab("Age") 

ggplot(a, aes(x=Credit.Amount, y=Age.years, shape=Creditability, color=Creditability)) + geom_point() +
  ggtitle("Scatterplot of Credit Amount v/s Age in Years") +
  xlab("Credit Amount") + ylab("Age") + theme(plot.title = element_text(hjust=0.5))

#3
df <- data.frame(country = c("India", "Germany", "China", "Pakistan", "Sweden"), birthrate = c(33, 16, 40, 35, 15))
df
ggplot(df, aes(country,birthrate )) + geom_col(fill = "blue") 
+ ggtitle("Birth rate for countries") + xlab("Country") 
+ ylab("Birth rate")+ theme(plot.title = element_text(hjust=0.5))

#4
df <- data.frame(country = c("Delhi", "Kolkata", "Mumbai", "Chennai", "Delhi", "Kolkata", "Mumbai", "Chennai"), temperature = c(40.5, 42.8, 37.8, 39.4, 34.7, 33.5, 32.2, 33.1), Level = c("Max","Max","Max","Max","Min","Min","Min","Min"))
df
ggplot(df, aes(country, temperature)) + geom_col(aes(fill = Level),position = "dodge") + ggtitle("Temperature in Cities") + xlab("Country") + ylab("Birth rate") +
  theme(plot.title = element_text(hjust=0.5))

#5
df <- data.frame(year = c("2000 - 2001", "2000 - 2001", "2000 - 2001", "2001 - 2002", "2001 - 2002", "2001 - 2002", "2002 - 2003", "2002 - 2003", "2002 - 2003"), marks = c(20, 10, 5, 25, 9, 10, 30, 20, 20), stream = c("Arts", "Science", "Law", "Arts", "Science", "Law", "Arts", "Science", "Law"))
df
ggplot(df, aes(year, marks)) + geom_col(aes(fill = stream)) + ggtitle("Year v/s Marks") + xlab("Year") + ylab("Marks") + theme(plot.title = element_text(hjust=0.5))

#6
df <- data.frame(Marks = c("5", "15", "25", "35", "45"), Students = c(6, 12, 25, 16, 11))
df
ggplot(df, aes(Marks, Students, group = 1)) + geom_point(color = "blue", size = 2) + geom_line() + ggtitle("Frequency Polygon")

#7
df <- data.frame(Items = c("Food","Clothing","Rent","Fuel and Lighting","Education","Miscellanoues"), Expenditure= c(240,66,125,57,42,190))
a<-ggplot(df, aes(x="", y=Expenditure, fill=Items))+geom_bar(width = 1,stat="identity")
a+coord_polar("y", start=0)+ ggtitle("Pie Chart")+theme(plot.title = element_text(hjust=0.5))


#Extra problems

d<-data.frame(year=c(2001,2002,2003,2004,2005),rainfall=c(195,228,186,205,246))
d
install.packages("ggplot2")
library(ggplot2)
si<-ggplot(data=d,aes(x=year,y=rainfall))+geom_bar(stat="identity")
si
a<-ggplot(d,aes(x=year,y=rainfall,fill="rainfall"))+geom_bar(stat="identity",width=0.6,color="yellow")+theme_minimal()
a
b<-a+geom_text(aes(label=rainfall),vjust=-0.3,size=3.5,color="green")
b
b+scale_fill_brewer(palette="dark2") 


d1<-data.frame(co=rep(c("USA","China","Italy"),2),rate=c("br","br","br","dr","dr","dr"),population=c(14.2,17.7.8.5.8.3.6.2.10.5))
d1
sbd<-ggplot(data=d1,aes(x=co,y=population,fill=rate))+geom_bar(stat="identity")
sbd
sb<-ggplot(data=d1,aes(x=co,y=population,fill=rate))+geom_bar(stat="identity",width=0.4,color="blue")
sb

d2<-data.frame(city=rep(c("Delhi","Kolkata","Mumbai","Chennai"),2),temp=c("Max","Max","Max","Max","Min","Min","Min","Min"),measure=c(40.5,42.8,37.8,39.4,34.7,33.5,32.2,33.1))
d2
mbd<-ggplot(data=d2,aes(x=city,y=measure,fill=temp))+geom_bar(stat="identity",width=0.4,position=position_dodge())
mbd

mbd+coord_flip()

d<-data.frame(item=c("food","clothing","Rent","Fuel and lighting","Education","Misc"),expen=c(240,66,125,57,42,190))
d
bp<-ggplot(d,aes(x="",y=expen,fill=item))+geom_bar(width=1.5,stat="identity")
bp
#create a pie chart
pie<-bp+coord_polar("y",start=0)
pie+theme(legend.position="top")